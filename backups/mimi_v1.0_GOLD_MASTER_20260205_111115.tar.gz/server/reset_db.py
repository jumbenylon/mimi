from app.database import SessionLocal, engine, Base
from app.models import Account, Transaction
from datetime import datetime, timedelta

# 1. NUKE EVERYTHING (Drop all tables)
print("⚠️  Dropping all data...")
Base.metadata.drop_all(bind=engine)

# 2. RE-CREATE TABLES (Clean Slate)
print("🛠  Creating fresh tables...")
Base.metadata.create_all(bind=engine)

db = SessionLocal()

# 3. SEED THE TRUTH
print("🌱 Seeding correct data...")

# A. Bank Account (SINGLE Entry) - 345M TZS Cash
bank = Account(name="CRDB Bank", type="BANK", balance=345000000.0)
db.add(bank)
db.commit() # Commit to get ID

# B. Loans (SINGLE Entries)
# LOLC: 21.4M Original, ~18.4M Remaining
lolc = Account(name="LOLC Finance", type="LOAN", balance=-18400000.0)
# Contract: 34.5M Original, ~32M Remaining
contract = Account(name="Contract Loan", type="LOAN", balance=-32000000.0)

db.add(lolc)
db.add(contract)

# C. Recent Transactions (Clean List - No Duplicates)
txs = [
    # Recent Income
    Transaction(date=datetime.now(), description="Project Alpha Payment", amount=5000000, category="Income", account_id=bank.id),
    
    # Recent Expenses
    Transaction(date=datetime.now(), description="Fuel (Puma)", amount=-120000, category="Transport", account_id=bank.id),
    Transaction(date=datetime.now() - timedelta(days=1), description="Business Lunch", amount=-45000, category="Food", account_id=bank.id),
    Transaction(date=datetime.now() - timedelta(days=3), description="Internet Package", amount=-150000, category="Utilities", account_id=bank.id),
    Transaction(date=datetime.now() - timedelta(days=5), description="Site Labor", amount=-350000, category="Business", account_id=bank.id),
]

db.add_all(txs)
db.commit()

print("✅ DATABASE RESET COMPLETE.")
print(f"   - Bank Balance: {bank.balance:,.0f} TZS")
print(f"   - Active Loans: 2")
print("   - You may now restart the server.")
db.close()
