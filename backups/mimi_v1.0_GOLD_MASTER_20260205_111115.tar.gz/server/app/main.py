from fastapi import FastAPI, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .database import SessionLocal, engine, Base, get_db
from .models import Account, Transaction
from sqlalchemy import Column, Integer, String, Float
from datetime import datetime, date
import calendar
from pydantic import BaseModel
from sqlalchemy import desc, func, extract, and_

# --- EXTENDED MODELS ---
class Goal(Base):
    __tablename__ = "goals"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    target_amount = Column(Float)
    current_amount = Column(Float)
    monthly_contribution = Column(Float)
    color = Column(String)

class Budget(Base):
    __tablename__ = "budgets"
    id = Column(Integer, primary_key=True, index=True)
    category = Column(String)
    limit_amount = Column(Float)

class Asset(Base):
    __tablename__ = "assets"
    id = Column(Integer, primary_key=True, index=True)
    category = Column(String)
    name = Column(String)
    quantity = Column(Float)
    buy_price = Column(Float)
    current_price = Column(Float)
    value = Column(Float)
    meta_data = Column(String)

Base.metadata.create_all(bind=engine)
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- 1. DASHBOARD ---
@app.get("/api/dashboard")
def get_dashboard(db: Session = Depends(get_db)):
    accounts = db.query(Account).all()
    bank_balance = sum(a.balance for a in accounts if a.type == "BANK")
    
    # Loans
    loan_accounts = db.query(Account).filter(Account.type == "LOAN").all()
    loans_data = []
    for loan in loan_accounts:
        name = loan.name.upper()
        current = abs(loan.balance)
        if "ECOBANK" in name: original = 34500000.0; next_due = "2026-02-25"
        elif "LOLC" in name: original = 21450000.0; next_due = "2026-03-01"
        else: original = current * 1.2; next_due = "Unknown"
        loans_data.append({"name": loan.name, "original": original, "balance": current, "paid": original - current, "next_due": next_due, "next_amount": 0})

    recent_txs = db.query(Transaction).order_by(Transaction.date.desc()).limit(10).all()
    goals = db.query(Goal).all()
    goals_data = [{"id": g.id, "name": g.name, "target": g.target_amount, "current": g.current_amount, "monthly": g.monthly_contribution, "color": g.color} for g in goals]
    
    # 2026 Summary
    start_2026 = date(2026, 1, 1)
    txs_2026 = db.query(Transaction).filter(Transaction.date >= start_2026).all()
    income_2026 = sum(t.amount for t in txs_2026 if t.amount > 0 and t.category == "Income")
    expense_2026 = sum(abs(t.amount) for t in txs_2026 if t.amount < 0 and t.category != "Investment") 

    return {
        "bank_balance": bank_balance,
        "loans": loans_data,
        "transactions": recent_txs or [],
        "goals": goals_data,
        "summary_2026": {"income": income_2026, "expense": expense_2026}
    }

# --- 2. INVESTMENTS (DYNAMIC) ---
@app.get("/api/investments")
def get_investments(db: Session = Depends(get_db)):
    assets = db.query(Asset).all()
    dse = []
    utt = []
    land = []
    vehicles = []

    for a in assets:
        # Calculate derived fields
        total_orig_cost = a.quantity * a.buy_price
        
        item = {
            "name": a.name, 
            "details": f"{int(a.quantity):,} units" if a.category != "Land" else f"{int(a.quantity)} {a.meta_data}", 
            "val": a.value,
            "sym": a.name, 
            "shares": a.quantity, 
            "buy_price": a.buy_price,
            "curr_price": a.current_price,
            "logo": a.meta_data,
            "trend": [a.buy_price, a.current_price],
            "acc": f"Qty: {a.quantity}"
        }
        
        if a.category == "DSE": dse.append(item)
        elif a.category == "UTT": utt.append(item)
        elif a.category == "Land": land.append(item)
        elif a.category == "Vehicles": vehicles.append(item)

    total_val = sum(a.value for a in assets)
    
    # Calculate Total Profit (Current Value - (Qty * Avg Buy Price))
    total_cost_basis = sum(a.quantity * a.buy_price for a in assets)

    return {
        "summary": {
            "total_value": total_val,
            "total_profit": total_val - total_cost_basis
        },
        "assets": [
            {"category": "DSE", "name": "Stock Exchange", "value": sum(x['val'] for x in dse), "stocks": dse},
            {"category": "UTT", "name": "UTT AMIS", "value": sum(x['val'] for x in utt), "funds": utt},
            {"category": "Land", "name": "Real Estate", "value": sum(x['val'] for x in land), "land": land},
            {"category": "Vehicles", "name": "Fleet", "value": sum(x['val'] for x in vehicles), "vehicles": vehicles}
        ]
    }

# --- 3. ANALYTICS ---
@app.get("/api/analytics")
def get_analytics(period: str = Query("ALL"), db: Session = Depends(get_db)):
    GLOBAL_START_DATE = date(2026, 1, 1)
    
    dates = db.query(extract('year', Transaction.date), extract('month', Transaction.date))\
              .filter(Transaction.date >= GLOBAL_START_DATE)\
              .distinct().order_by(desc(extract('year', Transaction.date)), desc(extract('month', Transaction.date))).all()
    available_periods = [f"{int(y)}-{int(m):02d}" for y, m in dates]

    trend_data = []
    if period == "ALL":
        periods_to_show = reversed(available_periods) if available_periods else []
        for p in periods_to_show: 
            y, m = map(int, p.split('-'))
            month_txs = db.query(Transaction).filter(extract('year', Transaction.date) == y, extract('month', Transaction.date) == m).all()
            inc = sum(t.amount for t in month_txs if t.amount > 0 and t.category == "Income")
            exp = sum(abs(t.amount) for t in month_txs if t.amount < 0 and t.category != "Investment")
            trend_data.append({"label": calendar.month_abbr[m], "income": inc, "expense": exp, "full_period": p})
        if not trend_data: trend_data.append({"label": "Jan", "income": 0, "expense": 0, "full_period": "2026-01"})
    else:
        y, m = map(int, period.split('-'))
        _, last_day = calendar.monthrange(y, m)
        month_txs = db.query(Transaction).filter(extract('year', Transaction.date) == y, extract('month', Transaction.date) == m).all()
        daily_map = {day: {"inc": 0, "exp": 0} for day in range(1, last_day + 1)}
        for t in month_txs:
            if t.amount > 0 and t.category == "Income": daily_map[t.date.day]["inc"] += t.amount
            elif t.amount < 0 and t.category != "Investment": daily_map[t.date.day]["exp"] += abs(t.amount)
        for day in range(1, last_day + 1):
            if daily_map[day]["inc"] > 0 or daily_map[day]["exp"] > 0:
                 trend_data.append({"label": f"{day}", "income": daily_map[day]["inc"], "expense": daily_map[day]["exp"], "full_period": period})

    query = db.query(Transaction).filter(Transaction.date >= GLOBAL_START_DATE)
    if period != "ALL":
        try:
            year, month = map(int, period.split('-'))
            _, last_day = calendar.monthrange(year, month)
            start_date = date(year, month, 1)
            end_date = date(year, month, last_day)
            query = query.filter(and_(Transaction.date >= start_date, Transaction.date <= end_date))
        except: pass

    transactions = query.all()
    income = sum(t.amount for t in transactions if t.amount > 0 and t.category == "Income")
    expenses = sum(abs(t.amount) for t in transactions if t.amount < 0 and t.category != "Investment")
    
    breakdown_map = {}
    for t in transactions:
        if t.amount >= 0 or t.category == "Investment": continue 
        cat = t.category
        if cat not in breakdown_map: breakdown_map[cat] = {"total": 0, "items": []}
        breakdown_map[cat]["total"] += abs(t.amount)
        breakdown_map[cat]["items"].append({"desc": t.description, "amount": abs(t.amount), "date": t.date})

    breakdown_list = []
    for cat, data in breakdown_map.items():
        breakdown_list.append({"name": cat, "value": data["total"], "items": sorted(data["items"], key=lambda x: x['amount'], reverse=True)})
    breakdown_list.sort(key=lambda x: x['value'], reverse=True)

    budgets = db.query(Budget).all()
    budget_status = []
    for b in budgets:
        spent = breakdown_map.get(b.category, {"total": 0})["total"]
        budget_status.append({"category": b.category, "limit": b.limit_amount, "spent": spent})

    return {"period": period, "available_periods": available_periods, "income": income, "expenses": expenses, "breakdown": breakdown_list, "budgets": budget_status, "trend": trend_data}

# --- 4. CREATE TRANSACTION (With Qty & Price) ---
class TransactionCreate(BaseModel):
    description: str
    amount: float
    category: str
    date: str
    asset_name: str = None 
    quantity: float = 0 # New Field
    buy_price: float = 0 # New Field

@app.post("/api/transactions")
def create_transaction(tx: TransactionCreate, db: Session = Depends(get_db)):
    account = db.query(Account).filter(Account.type == "BANK").first()
    
    # 1. Determine Amount (For Investment, Amount = Qty * Price)
    if tx.category == "Investment" and tx.quantity > 0:
        total_cost = tx.quantity * tx.buy_price
        real_amount = -abs(total_cost) # Outflow
        final_desc = f"Buy {int(tx.quantity)} {tx.asset_name} @ {int(tx.buy_price)}"
    else:
        real_amount = abs(tx.amount) if "Income" in tx.category else -abs(tx.amount)
        total_cost = abs(tx.amount)
        final_desc = tx.description

    # 2. Handle ASSET UPDATE
    if tx.category == "Investment" and tx.asset_name:
        asset = db.query(Asset).filter(Asset.name == tx.asset_name).first()
        if asset:
            # Weighted Average Logic:
            old_total_cost = asset.quantity * asset.buy_price
            new_total_cost = old_total_cost + total_cost
            new_qty = asset.quantity + tx.quantity
            
            asset.quantity = new_qty
            asset.buy_price = new_total_cost / new_qty # New Avg Price
            asset.value = new_qty * asset.current_price # Update total value based on market price
            
            # Optional: If you want to simulate market movement, assume buy price = current price for now
            # asset.current_price = tx.buy_price 

    # 3. Create Transaction Record
    new_tx = Transaction(
        date=datetime.strptime(tx.date, "%Y-%m-%d"),
        description=final_desc,
        amount=real_amount,
        category=tx.category,
        account_id=account.id if account else 1
    )
    
    if account: account.balance += real_amount
    db.add(new_tx)
    db.commit()
    return {"status": "success", "id": new_tx.id}

# --- 5. SETTINGS: RESET DATA ---
@app.delete("/api/settings/reset")
def reset_data(db: Session = Depends(get_db)):
    db.query(Transaction).delete()
    bank = db.query(Account).filter(Account.type == "BANK").first()
    if bank: bank.balance = 5982884.0 
    db.commit()
    return {"status": "success", "message": "Data wiped successfully"}
