from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from .database import Base

class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True)
    type = Column(String) 
    balance = Column(Float, default=0.0)
    transactions = relationship("Transaction", back_populates="account")
    schedule = relationship("LoanInstallment", back_populates="account")

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime)
    description = Column(String)
    amount = Column(Float)
    category = Column(String)
    account_id = Column(Integer, ForeignKey("accounts.id"))
    account = relationship("Account", back_populates="transactions")

class LoanInstallment(Base):
    __tablename__ = "loan_schedule"
    id = Column(Integer, primary_key=True, index=True)
    due_date = Column(DateTime)
    amount = Column(Float)
    is_paid = Column(Boolean, default=False)
    account_id = Column(Integer, ForeignKey("accounts.id"))
    account = relationship("Account", back_populates="schedule")
