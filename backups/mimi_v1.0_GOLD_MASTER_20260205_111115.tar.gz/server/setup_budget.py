from app.database import SessionLocal, engine, Base
from sqlalchemy import Column, Integer, String, Float

# Define Budget Model temporarily to create table
class Budget(Base):
    __tablename__ = "budgets"
    id = Column(Integer, primary_key=True, index=True)
    category = Column(String, unique=True)
    limit_amount = Column(Float)

Base.metadata.create_all(bind=engine)

db = SessionLocal()
print("📉 Configuring Spending Buckets...")

# Clear old budgets
db.query(Budget).delete()

# Define Categories
buckets = [
    {"cat": "Transport & Fuel", "limit": 600000.0},
    {"cat": "Food & Groceries", "limit": 500000.0},
    {"cat": "Utilities", "limit": 200000.0},
    {"cat": "Entertainment", "limit": 300000.0},
    {"cat": "Fitness & Health", "limit": 150000.0},
    {"cat": "Family Support", "limit": 200000.0},
    {"cat": "Emergency Fund", "limit": 750000.0},
]

for b in buckets:
    new_b = Budget(category=b["cat"], limit_amount=b["limit"])
    db.add(new_b)

db.commit()
print("✅ BUDGETS ACTIVATED.")
db.close()
