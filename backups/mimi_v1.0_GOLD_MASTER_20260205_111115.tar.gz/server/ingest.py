import sys
import os
# Fix python path
sys.path.append(os.getcwd())

from server.app.services.pdf_parser import parse_ecobank_statement
from server.app.database import SessionLocal
from server.app.models import Account

# 1. Get the Main Account ID
db = SessionLocal()
ecobank = db.query(Account).filter(Account.type == "BANK").first()
if not ecobank:
    print("❌ Error: No Bank Account found in DB. Run seed first.")
    sys.exit(1)

# 2. Path to your uploaded file (Current directory)
# Note: In a real app, this comes from a file upload form.
# Here we point to the file we know exists in your folder context.
pdf_file = "707XXXX307_unlocked.pdf" 

if os.path.exists(pdf_file):
    parse_ecobank_statement(pdf_file, ecobank.id)
else:
    print(f"❌ File not found: {pdf_file}. Make sure the PDF is in the root folder.")
