from app.database import SessionLocal, engine, Base
from sqlalchemy import text, Column, Integer, String, Float

# 1. Define the Correct New Model
class Asset(Base):
    __tablename__ = "assets"
    id = Column(Integer, primary_key=True, index=True)
    category = Column(String)
    name = Column(String)
    quantity = Column(Float)   # The new column causing the error
    buy_price = Column(Float)  # The new column causing the error
    current_price = Column(Float)
    value = Column(Float)
    meta_data = Column(String)

# 2. Connect and Fix
db = SessionLocal()
print("🔧 FIXING DATABASE SCHEMA...")

try:
    # A. FORCE DELETE the old table
    with engine.connect() as conn:
        conn.execute(text("DROP TABLE IF EXISTS assets"))
        conn.commit()
    print("   - Old 'assets' table dropped.")

    # B. Create the NEW table with correct columns
    Base.metadata.create_all(bind=engine)
    print("   - New 'assets' table created with 'quantity' column.")

    # C. Seed Data
    portfolio = [
        {"cat": "DSE", "name": "CRDB", "qty": 1744, "buy": 678, "curr": 2320, "meta": "/crdb.png"},
        {"cat": "DSE", "name": "NICO", "qty": 720,  "buy": 774, "curr": 3350, "meta": "/nico.webp"},
        {"cat": "DSE", "name": "NMB",  "qty": 100,  "buy": 5100, "curr": 11110, "meta": "/nmb.jpeg"},
        {"cat": "DSE", "name": "DCB",  "qty": 180,  "buy": 166, "curr": 350,   "meta": "/dcb.jpeg"},
        {"cat": "UTT", "name": "Umoja Unit Trust", "qty": 1500, "buy": 800, "curr": 950, "meta": ""},
        {"cat": "Land", "name": "Arusha (Nambala)", "qty": 740, "buy": 16891, "curr": 16891, "meta": "Sqm"},
        {"cat": "Land", "name": "Kinondoni Shamba", "qty": 357, "buy": 54621, "curr": 54621, "meta": "Sqm"},
        {"cat": "Vehicles", "name": "BMW X3", "qty": 1, "buy": 43800000, "curr": 43800000, "meta": "Premium Insured"}
    ]

    for p in portfolio:
        total_val = p["qty"] * p["curr"]
        db.add(Asset(
            category=p["cat"], 
            name=p["name"], 
            quantity=float(p["qty"]),
            buy_price=float(p["buy"]),
            current_price=float(p["curr"]),
            value=total_val,
            meta_data=p["meta"]
        ))

    db.commit()
    print("✅ SUCCESS: Database is now compatible with the code.")

except Exception as e:
    print(f"❌ ERROR: {e}")

finally:
    db.close()
