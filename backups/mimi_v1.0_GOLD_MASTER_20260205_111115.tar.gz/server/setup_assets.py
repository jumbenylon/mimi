from app.database import SessionLocal, engine, Base
from sqlalchemy import Column, Integer, String, Float

# 1. Define Precise Asset Model
class Asset(Base):
    __tablename__ = "assets"
    id = Column(Integer, primary_key=True, index=True)
    category = Column(String)  # DSE, UTT
    name = Column(String)      # CRDB
    quantity = Column(Float)   # 1744.0
    buy_price = Column(Float)  # 678.0 (Average Cost Basis)
    current_price = Column(Float) # 2320.0 (Market Price)
    value = Column(Float)      # Total Value (Qty * Curr Price)
    meta_data = Column(String) # Logo

Base.metadata.create_all(bind=engine)

db = SessionLocal()
print("📈 Upgrading Portfolio Precision...")

# 2. Reset Table
db.query(Asset).delete()

# 3. Seed with Precise Data
portfolio = [
    # DSE STOCKS (Qty, Buy Price, Current Price)
    {"cat": "DSE", "name": "CRDB", "qty": 1744, "buy": 678, "curr": 2320, "meta": "/crdb.png"},
    {"cat": "DSE", "name": "NICO", "qty": 720,  "buy": 774, "curr": 3350, "meta": "/nico.webp"},
    {"cat": "DSE", "name": "NMB",  "qty": 100,  "buy": 5100, "curr": 11110, "meta": "/nmb.jpeg"},
    {"cat": "DSE", "name": "DCB",  "qty": 180,  "buy": 166, "curr": 350,   "meta": "/dcb.jpeg"},
    # UTT FUNDS (Qty = Units)
    {"cat": "UTT", "name": "Umoja Unit Trust", "qty": 1500, "buy": 800, "curr": 950, "meta": ""},
    # LAND (Qty = 1, Buy = Total Cost, Curr = Valuation)
    {"cat": "Land", "name": "Arusha (Nambala)", "qty": 740, "buy": 16891, "curr": 16891, "meta": "Sqm"},
    {"cat": "Land", "name": "Kinondoni Shamba", "qty": 357, "buy": 54621, "curr": 54621, "meta": "Sqm"},
    # VEHICLES
    {"cat": "Vehicles", "name": "BMW X3", "qty": 1, "buy": 43800000, "curr": 43800000, "meta": "Premium Insured"}
]

for p in portfolio:
    # Calculate Total Value automatically
    total_val = p["qty"] * p["curr"]
    
    db.add(Asset(
        category=p["cat"], 
        name=p["name"], 
        quantity=float(p["qty"]),
        buy_price=float(p["buy"]),
        current_price=float(p["curr"]),
        value=total_val,
        meta_data=p["meta"]
    ))

db.commit()
print("✅ PORTFOLIO UPGRADED.")
db.close()
