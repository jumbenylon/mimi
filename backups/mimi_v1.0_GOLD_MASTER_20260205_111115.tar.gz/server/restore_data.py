from app.database import SessionLocal, engine, Base
from app.main import Asset # Import the model from main to ensure matching schema
from sqlalchemy import text

db = SessionLocal()
print("♻️ RESTORING YOUR DATA...")

try:
    # 1. Clear empty table
    with engine.connect() as conn:
        conn.execute(text("DELETE FROM assets"))
        conn.commit()

    # 2. Re-insert YOUR specific data
    # Note: For assets like Land/Cars where "Buy Price" wasn't tracked, 
    # we set Buy Price = Current Value so Profit is 0 until you update it.
    
    portfolio = [
        # --- STOCKS (DSE) ---
        {"cat": "DSE", "name": "CRDB", "qty": 1744, "buy": 678, "curr": 2320, "meta": "/crdb.png"},
        {"cat": "DSE", "name": "NICO", "qty": 720,  "buy": 774, "curr": 3350, "meta": "/nico.webp"},
        {"cat": "DSE", "name": "NMB",  "qty": 100,  "buy": 5100, "curr": 11110, "meta": "/nmb.jpeg"},
        {"cat": "DSE", "name": "DCB",  "qty": 180,  "buy": 166, "curr": 350,   "meta": "/dcb.jpeg"},
        {"cat": "DSE", "name": "MBP",  "qty": 20,   "buy": 350, "curr": 1240,  "meta": "/mkb.png"},
        {"cat": "DSE", "name": "PAL",  "qty": 10,   "buy": 360, "curr": 310,   "meta": "/precision.jpg"},

        # --- FUNDS (UTT) --- 
        # Restoring as 1 unit with total value since we don't have exact unit counts yet
        {"cat": "UTT", "name": "Umoja Unit Trust", "qty": 1, "buy": 10000, "curr": 10000, "meta": "191558920"},
        {"cat": "UTT", "name": "Wekeza Maisha",    "qty": 1, "buy": 10000, "curr": 10000, "meta": "200146813"},
        {"cat": "UTT", "name": "Watoto Fund",      "qty": 1, "buy": 10000, "curr": 10000, "meta": "300222246"},
        {"cat": "UTT", "name": "Jikimu Fund",      "qty": 1, "buy": 10000, "curr": 10000, "meta": "400165074"},
        {"cat": "UTT", "name": "Liquid Fund",      "qty": 1, "buy": 10000, "curr": 10000, "meta": "501044095"},
        {"cat": "UTT", "name": "Bond Fund",        "qty": 1, "buy": 10000, "curr": 10000, "meta": "600374330"},

        # --- LAND ---
        # Qty = Sqm, Price = Value per Sqm (Calculated)
        {"cat": "Land", "name": "Arusha (Nambala)", "qty": 740, "buy": 16891, "curr": 16891, "meta": "Sqm"},
        {"cat": "Land", "name": "Arusha (Nganana)", "qty": 800, "buy": 11875, "curr": 11875, "meta": "Sqm"},
        {"cat": "Land", "name": "Mabwepande",       "qty": 800, "buy": 23750, "curr": 23750, "meta": "Sqm"},
        {"cat": "Land", "name": "Kinondoni Shamba", "qty": 357, "buy": 54621, "curr": 54621, "meta": "Sqm"},

        # --- VEHICLES ---
        {"cat": "Vehicles", "name": "BMW X3",       "qty": 1, "buy": 43800000, "curr": 43800000, "meta": "Premium Insured"},
        {"cat": "Vehicles", "name": "BMW 1 Series", "qty": 1, "buy": 16000000, "curr": 16000000, "meta": "Premium Insured"},
        {"cat": "Vehicles", "name": "Toyota Chaser", "qty": 1, "buy": 3000000,  "curr": 3000000,  "meta": "3rd Party Insured"}
    ]

    for p in portfolio:
        total_val = p["qty"] * p["curr"]
        db.add(Asset(
            category=p["cat"], 
            name=p["name"], 
            quantity=float(p["qty"]),
            buy_price=float(p["buy"]),
            current_price=float(p["curr"]),
            value=total_val,
            meta_data=p["meta"]
        ))

    db.commit()
    print("✅ RESTORE COMPLETE: All assets are back.")

except Exception as e:
    print(f"❌ ERROR: {e}")

finally:
    db.close()
