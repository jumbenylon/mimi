from app.database import SessionLocal, engine, Base
from app.models import Account, Transaction

db = SessionLocal()
print("💰 Configuring Liquid Assets (Banks)...")

# 1. PREPARE CLEAN SLATE
# Find existing bank accounts
existing_banks = db.query(Account).filter(Account.type == "BANK").all()
bank_ids = [acc.id for acc in existing_banks]

# Delete any old transactions linked to these old bank accounts (to avoid errors)
if bank_ids:
    deleted_tx = db.query(Transaction).filter(Transaction.account_id.in_(bank_ids)).delete(synchronize_session=False)
    print(f"   - Cleared {deleted_tx} old bank transactions.")

# Delete the old bank accounts
db.query(Account).filter(Account.type == "BANK").delete(synchronize_session=False)
db.commit()

# 2. INJECT NEW BALANCES (The Truth)
banks = [
    {"name": "Ecobank", "balance": 4529727.32},
    {"name": "Selcom", "balance": 1227885.30},
    {"name": "CRDB Bank", "balance": 225271.44},
]

for b in banks:
    acc = Account(name=b["name"], type="BANK", balance=b["balance"])
    db.add(acc)

db.commit()

# 3. VERIFY
total_cash = sum(b["balance"] for b in banks)
print(f"✅ SUCCESS: Bank Balances Updated.")
print(f"   - Ecobank: {banks[0]['balance']:,.2f}")
print(f"   - Selcom:  {banks[1]['balance']:,.2f}")
print(f"   - CRDB:    {banks[2]['balance']:,.2f}")
print(f"   ---------------------------")
print(f"   - TOTAL CASH: {total_cash:,.2f} TZS")

db.close()
