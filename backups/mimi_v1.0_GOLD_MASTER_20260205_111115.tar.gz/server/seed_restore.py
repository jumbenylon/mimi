from app.database import SessionLocal, engine, Base
from app.models import Account, Transaction
from datetime import datetime, timedelta

# Init DB
Base.metadata.create_all(bind=engine)
db = SessionLocal()

print("Checking Database...")

# 1. Check/Create Bank Account
bank = db.query(Account).filter(Account.type == "BANK").first()
if not bank:
    print("Seeding Bank Account...")
    bank = Account(name="CRDB Bank", type="BANK", balance=345000000.0) # 345M Cash
    db.add(bank)
    db.commit()
    db.refresh(bank)
else:
    print("Bank Account exists.")

# 2. Check/Create Loan Accounts
loans = db.query(Account).filter(Account.type == "LOAN").all()
if not loans:
    print("Seeding Loans...")
    lolc = Account(name="LOLC Finance", type="LOAN", balance=-18400000.0)
    contract = Account(name="Contract Loan", type="LOAN", balance=-32000000.0)
    db.add(lolc)
    db.add(contract)
    db.commit()
else:
    print("Loans exist.")

# 3. Add Dummy Transactions if empty (to prevent 'Empty Dashboard' look)
tx_count = db.query(Transaction).count()
if tx_count == 0:
    print("Seeding Transactions...")
    txs = [
        Transaction(date=datetime.now(), description="Project Alpha Payment", amount=5000000, category="Income", account_id=bank.id),
        Transaction(date=datetime.now(), description="Fuel (Puma)", amount=-120000, category="Transport", account_id=bank.id),
        Transaction(date=datetime.now() - timedelta(days=1), description="Lunch Meeting", amount=-45000, category="Food", account_id=bank.id),
        Transaction(date=datetime.now() - timedelta(days=2), description="Internet Bill", amount=-150000, category="Utilities", account_id=bank.id),
    ]
    db.add_all(txs)
    db.commit()

print("✅ RESTORE COMPLETE. Dashboard Data is ready.")
db.close()
