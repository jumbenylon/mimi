from app.database import SessionLocal, engine, Base
from app.models import Account, Transaction
from datetime import datetime, date
from dateutil.relativedelta import relativedelta

db = SessionLocal()

print("🏦  Configuring ECOBANK Refinance Loan...")

# 1. DELETE OLD LOANS (Clean Slate)
old_loans = db.query(Account).filter(Account.type == "LOAN").all()
for loan in old_loans:
    db.delete(loan)
db.commit()

# 2. CREATE ECOBANK LOAN (The Truth)
# Original: 34,500,000
# Balance as of Feb 2026 (from Schedule): ~23,097,352
ecobank = Account(
    name="ECOBANK Loan", 
    type="LOAN", 
    balance=-23097352.83 # Negative because it's debt
)
db.add(ecobank)
db.commit() # Commit to get ID

# 3. LOG HISTORICAL REPAYMENTS (Jan 2025 - Jan 2026)
# Amount per month: 1,217,527.24
monthly_payment = 1217527.24
start_date = date(2025, 1, 25)
today = date.today()

# Loop through months from Start Date until Today
current_payment_date = start_date
count = 0

print("📝  Logging historical repayments...")

while current_payment_date <= today:
    # Create the transaction record
    tx = Transaction(
        date=current_payment_date,
        description=f"Loan Repayment (Installment {count + 1})",
        amount=-monthly_payment, # Money leaving
        category="Debt Repayment",
        account_id=ecobank.id # Linked to this loan
    )
    db.add(tx)
    
    # Move to next month
    current_payment_date += relativedelta(months=1)
    count += 1

db.commit()

print(f"✅ SUCCESS: Ecobank Loan Setup.")
print(f"   - Current Balance: {ecobank.balance:,.2f} TZS")
print(f"   - History: {count} repayments logged automatically.")
print("🚀  You may now restart the server.")

db.close()
