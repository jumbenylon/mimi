from app.database import SessionLocal, engine, Base
from app.models import Account, Transaction
from datetime import datetime

# 1. Force Clean Slate
print("🛠  Creating fresh database tables...")
Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)

db = SessionLocal()

# 2. Create Accounts (The Truth)
print("🌱 Seeding Accounts...")

# A. Bank Account (Set to 0 initially to avoid wrong guesses)
bank = Account(name="CRDB Bank", type="BANK", balance=0.0)
db.add(bank)
db.commit() # Commit to generate ID

# B. Loans (Correct Contract & LOLC data)
# Note: Balances are negative to represent debt
lolc = Account(name="LOLC Finance", type="LOAN", balance=-18400000.0) 
contract = Account(name="Contract Loan", type="LOAN", balance=-32000000.0)

db.add(lolc)
db.add(contract)
db.commit()

# 3. Initial "Setup" Transaction
# This ensures the dashboard isn't empty, but doesn't inflate the balance.
init_tx = Transaction(
    date=datetime.now(),
    description="System Initialization",
    amount=0.0,
    category="Admin",
    account_id=bank.id
)
db.add(init_tx)
db.commit()

print("✅ SEED COMPLETE.")
print(f"   - Bank Account: Created (Balance: {bank.balance})")
print(f"   - Loans: LOLC & Contract Created")
print("   - Investments: Configured in main.py (DSE/UTT/Land)")
print("🚀 You may now start the server.")

db.close()
