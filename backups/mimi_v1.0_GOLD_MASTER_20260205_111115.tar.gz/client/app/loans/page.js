"use client";
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, CreditCard, Calendar, AlertCircle } from 'lucide-react';
import GlobalNav from '../components/GlobalNav';
import CollapsibleSection from '../components/CollapsibleSection';

export default function LoansPage() {
  const [data, setData] = useState(null);
  useEffect(() => { fetch('http://localhost:8000/api/dashboard').then((res) => res.json()).then(setData); }, []);
  const fmt = (n) => new Intl.NumberFormat('en-TZ', { style: 'currency', currency: 'TZS', maximumFractionDigits: 0 }).format(n || 0);

  if (!data) return <div className="min-h-screen bg-[#F3F4F6] flex items-center justify-center text-gray-500 font-medium">Loading Loans...</div>;

  return (
    <div className="min-h-screen bg-[#F3F4F6] pb-32 font-sans text-gray-900">
      <div className="bg-white px-6 pt-12 pb-6 border-b border-gray-200 sticky top-0 z-20">
        <div className="flex items-center gap-3 mb-4">
           <Link href="/"><div className="p-2 bg-gray-100 rounded-full text-gray-600"><ArrowLeft size={20} /></div></Link>
           <h2 className="text-xl font-bold tracking-tight">Debt Portfolio</h2>
        </div>
        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Total Outstanding</p>
        <h1 className="text-3xl font-bold text-red-600 tracking-tight">{fmt(data.loans.reduce((acc, l) => acc + l.balance, 0))}</h1>
      </div>

      <div className="p-6">
        <CollapsibleSection title={`Active Loans (${data.loans.length})`} icon={CreditCard}>
          <div className="grid gap-4">
            {data.loans.map((loan, i) => (
              <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5"><CreditCard size={100} className="text-gray-900" transform="rotate(-15)" /></div>
                <div className="relative z-10">
                  <div className="flex justify-between items-start mb-6">
                    <div><p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Lender</p><p className="font-bold text-xl text-gray-900 w-3/4 leading-tight">{loan.name}</p></div>
                    <div className="text-right"><p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Balance</p><p className="font-bold text-xl text-red-600">{fmt(loan.balance)}</p></div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-bold text-gray-500"><span>Progress</span><span>{Math.round((loan.paid / loan.original) * 100)}%</span></div>
                    <div className="w-full bg-gray-100 rounded-full h-2"><div className="bg-gray-800 h-2 rounded-full" style={{ width: `${(loan.paid / loan.original) * 100}%` }}></div></div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-50 flex justify-between items-center text-xs font-medium">
                      <span className="text-gray-500 flex items-center gap-1"><Calendar size={12}/> Due: {loan.next_due}</span>
                      <span className="text-gray-400">Original: {fmt(loan.original)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CollapsibleSection>
      </div>
      <GlobalNav />
    </div>
  );
}
