"use client";
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, ChevronDown, PieChart, List, BarChart2 } from 'lucide-react';
import GlobalNav from '../components/GlobalNav';
import CollapsibleSection from '../components/CollapsibleSection';
import { AreaChart, Area, XAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function AnalyticsPage() {
  const [data, setData] = useState(null);
  const [period, setPeriod] = useState("ALL");
  const [isPeriodMenuOpen, setIsPeriodMenuOpen] = useState(false);

  useEffect(() => { fetch(`http://localhost:8000/api/analytics?period=${period}`).then((res) => res.json()).then(setData); }, [period]);
  const fmt = (n) => new Intl.NumberFormat('en-TZ', { style: 'currency', currency: 'TZS', maximumFractionDigits: 0 }).format(n || 0);

  if (!data) return <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center text-gray-400 font-medium">Loading Analysis...</div>;

  // 1. PREPARE DATA
  const rawData = period === "ALL" ? (data.trend ? [...data.trend].reverse() : []) : data.trend;
  
  // 2. THE "MOUNTAIN" FIX: 
  // If we only have 1 data point (Jan), inject a "Start" point at 0 so the graph slopes up nicely.
  const chartData = rawData.length === 1 
      ? [{ label: '', income: 0, expense: 0 }, ...rawData] 
      : rawData;

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-32 font-sans text-gray-900">
      
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md px-6 pt-12 pb-6 border-b border-gray-100 sticky top-0 z-20">
        <div className="flex items-center gap-3 mb-6">
           <Link href="/"><div className="p-2 bg-gray-50 rounded-full text-gray-500 hover:bg-gray-100 transition"><ArrowLeft size={20} /></div></Link>
           <h2 className="text-xl font-semibold tracking-tight text-gray-900">Analysis</h2>
           
           <div className="ml-auto relative">
              <button onClick={() => setIsPeriodMenuOpen(!isPeriodMenuOpen)} className="bg-gray-50 px-3 py-1.5 rounded-lg flex items-center gap-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 transition">
                 <span>{period === "ALL" ? "All Time" : period}</span>
                 <ChevronDown size={14} />
              </button>
              {isPeriodMenuOpen && (
                 <div className="absolute right-0 top-10 w-32 bg-white rounded-xl shadow-xl border border-gray-100 p-2 z-50 animate-in fade-in zoom-in-95 duration-200">
                    <button onClick={() => {setPeriod("ALL"); setIsPeriodMenuOpen(false)}} className="w-full text-left px-3 py-2 hover:bg-gray-50 text-xs font-semibold rounded-lg text-gray-700">All Time</button>
                    {data.available_periods?.map(p => (
                       <button key={p} onClick={() => {setPeriod(p); setIsPeriodMenuOpen(false)}} className="w-full text-left px-3 py-2 hover:bg-gray-50 text-xs font-semibold rounded-lg text-gray-700">{p}</button>
                    ))}
                 </div>
              )}
           </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div><p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">Money In</p><p className="text-2xl font-bold text-emerald-600 tracking-tight">{fmt(data.income)}</p></div>
          <div className="text-right"><p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">Money Out</p><p className="text-2xl font-bold text-rose-600 tracking-tight">{fmt(data.expenses)}</p></div>
        </div>
      </div>

      <div className="p-6 space-y-6">

        {/* PREMIUM INTERACTIVE CHART (No Dots, Smooth Curve) */}
        <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm">
           <div className="flex items-center gap-2 mb-6">
              <div className="p-2 bg-purple-50 text-purple-600 rounded-xl"><BarChart2 size={18} /></div>
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">{period === "ALL" ? "Monthly Trend" : "Daily Activity"}</h3>
           </div>
           
           <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorInc" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10B981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#F43F5E" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#F43F5E" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                  <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#9CA3AF'}} dy={10} />
                  <Tooltip 
                    contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)'}} 
                    itemStyle={{fontSize: '12px', fontWeight: 600}}
                    formatter={(value) => new Intl.NumberFormat('en-TZ', { notation: "compact", compactDisplay: "short" }).format(value)}
                  />
                  {/* dot={false} hides the ugly dots. activeDot makes it pop only when you touch it. */}
                  <Area type="monotone" dataKey="income" stroke="#10B981" strokeWidth={3} fillOpacity={1} fill="url(#colorInc)" dot={false} activeDot={{r: 6, strokeWidth: 0}} />
                  <Area type="monotone" dataKey="expense" stroke="#F43F5E" strokeWidth={3} fillOpacity={1} fill="url(#colorExp)" dot={false} activeDot={{r: 6, strokeWidth: 0}} />
                </AreaChart>
              </ResponsiveContainer>
           </div>
        </div>

        {/* Budgets */}
        <CollapsibleSection title="Monthly Limits" icon={PieChart}>
           {data.budgets && data.budgets.length > 0 ? (
               <div className="space-y-3">{data.budgets.map((b, i) => (<div key={i} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm"><div className="flex justify-between mb-2"><span className="font-semibold text-sm text-gray-900">{b.category}</span><span className="text-xs font-semibold text-gray-500">{fmt(b.spent)} / {fmt(b.limit)}</span></div><div className="w-full bg-gray-100 h-2 rounded-full"><div className={`h-2 rounded-full transition-all duration-500 ${b.spent > b.limit ? 'bg-rose-500' : 'bg-emerald-500'}`} style={{width: `${Math.min((b.spent/b.limit)*100, 100)}%`}}></div></div></div>))}</div>
           ) : (<div className="p-4 bg-white rounded-2xl border border-dashed border-gray-300 text-center text-xs text-gray-400">No budget limits set.</div>)}
        </CollapsibleSection>

        {/* Breakdown */}
        <CollapsibleSection title="Spending Breakdown" icon={List}>
           <div className="space-y-4">{data.breakdown.map((cat, i) => (<div key={i} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"><div className="p-4 flex justify-between items-center border-b border-rose-500 border-b-2"><div><p className="font-semibold text-gray-900">{cat.name}</p><p className="text-xs text-gray-400 font-medium">{Math.round((cat.value / data.expenses) * 100)}% of total</p></div><p className="font-bold text-gray-900">{fmt(cat.value)}</p></div><div className="bg-gray-50 px-4 py-2">{cat.items.map((item, idx) => (<div key={idx} className="flex justify-between py-3 border-b border-gray-200 last:border-0 text-sm"><span className="text-gray-600 font-medium">{item.desc}</span><span className="font-semibold text-gray-900">{fmt(item.amount)}</span></div>))}</div></div>))}</div>
        </CollapsibleSection>
      </div>
      <GlobalNav />
    </div>
  );
}
