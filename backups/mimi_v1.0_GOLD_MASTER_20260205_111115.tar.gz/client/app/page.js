"use client";
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Menu, TrendingUp, ArrowUpRight, ArrowDownRight, Wallet, CreditCard, PieChart, ChevronRight, ShieldCheck } from 'lucide-react';
import GlobalNav from './components/GlobalNav';

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [investData, setInvestData] = useState(null);

  useEffect(() => { 
      fetch('http://localhost:8000/api/dashboard').then((res) => res.json()).then(setData);
      fetch('http://localhost:8000/api/investments').then((res) => res.json()).then(setInvestData);
  }, []);

  const fmt = (n) => new Intl.NumberFormat('en-TZ', { style: 'currency', currency: 'TZS', maximumFractionDigits: 0 }).format(n || 0);

  if (!data || !investData) return <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center text-gray-400 font-medium">Loading Command Center...</div>;

  const totalDebt = data.loans.reduce((acc, l) => acc + l.balance, 0);
  const income2026 = data.summary_2026?.income || 0;
  const expense2026 = data.summary_2026?.expense || 0;

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-32 font-sans text-gray-900 selection:bg-gray-900 selection:text-white">
      
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md px-6 pt-12 pb-4 sticky top-0 z-20">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
             <img src="/jumbenylon-logo.png" className="h-9 w-9 object-contain rounded-full border border-gray-200" />
             <span className="font-semibold text-lg tracking-tight text-gray-900">JumbeNylon</span>
          </div>
          <button className="p-2 bg-gray-50 rounded-full text-gray-500 hover:bg-gray-100 transition"><Menu size={20} /></button>
        </div>
      </div>

      <div className="px-6 space-y-6">
        
        {/* HERO CARD: Total Liquidity */}
        <div className="relative overflow-hidden bg-gray-900 rounded-[2.5rem] p-8 shadow-2xl shadow-gray-200 text-white">
           <div className="absolute top-0 right-0 p-8 opacity-10"><ShieldCheck size={120} /></div>
           <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-500 rounded-full blur-[80px] opacity-20"></div>
           <div className="relative z-10">
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-2">Total Liquidity</p>
              <h1 className="text-4xl font-bold tracking-tight text-white mb-6">{fmt(data.bank_balance)}</h1>
              
              <div className="flex gap-4">
                 <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-2xl border border-white/5">
                    <p className="text-[10px] text-gray-400 font-medium uppercase">2026 Income</p>
                    <p className="text-sm font-semibold text-emerald-400">+{fmt(income2026)}</p>
                 </div>
                 <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-2xl border border-white/5">
                    <p className="text-[10px] text-gray-400 font-medium uppercase">2026 Spend</p>
                    <p className="text-sm font-semibold text-rose-400">-{fmt(expense2026)}</p>
                 </div>
              </div>
           </div>
        </div>

        {/* METRICS GRID */}
        <div className="grid grid-cols-2 gap-4">
            <Link href="/invest" className="bg-white p-5 rounded-3xl shadow-[0_2px_20px_-12px_rgba(0,0,0,0.1)] border border-gray-100 active:scale-95 transition">
               <div className="p-2.5 bg-emerald-50 w-fit rounded-xl text-emerald-600 mb-3"><TrendingUp size={20} /></div>
               <p className="text-xs text-gray-400 font-medium uppercase tracking-wide">Net Worth</p>
               <p className="text-lg font-bold text-gray-900 mt-1 truncate">{fmt(investData.summary.total_value)}</p>
            </Link>

            <Link href="/loans" className="bg-white p-5 rounded-3xl shadow-[0_2px_20px_-12px_rgba(0,0,0,0.1)] border border-gray-100 active:scale-95 transition">
               <div className="p-2.5 bg-rose-50 w-fit rounded-xl text-rose-600 mb-3"><CreditCard size={20} /></div>
               <p className="text-xs text-gray-400 font-medium uppercase tracking-wide">Total Debt</p>
               <p className="text-lg font-bold text-gray-900 mt-1 truncate">{fmt(totalDebt)}</p>
            </Link>
        </div>

        {/* RECENT ACTIVITY SNIPPET */}
        <div>
           <div className="flex justify-between items-center px-2 mb-3">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Latest</h3>
              <Link href="/analytics" className="text-xs font-bold text-blue-600 hover:text-blue-700">View All</Link>
           </div>
           <div className="bg-white rounded-[2rem] border border-gray-100 shadow-[0_2px_20px_-12px_rgba(0,0,0,0.1)] overflow-hidden">
             {data.transactions.slice(0, 3).map((tx, i) => (
               <div key={i} className="p-5 border-b border-gray-50 last:border-0 flex justify-between items-center hover:bg-gray-50 transition cursor-pointer">
                 <div className="flex items-center gap-4">
                   <div className={`p-2.5 rounded-2xl ${tx.amount > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-50 text-gray-600'}`}>
                     {tx.amount > 0 ? <ArrowUpRight size={18} /> : <ArrowDownRight size={18} />}
                   </div>
                   <div>
                      <p className="text-sm font-semibold text-gray-900">{tx.description}</p>
                      <p className="text-[10px] text-gray-400 font-medium">{new Date(tx.date).toLocaleDateString()}</p>
                   </div>
                 </div>
                 <span className={`text-sm font-bold ${tx.amount > 0 ? 'text-emerald-600' : 'text-gray-900'}`}>{fmt(tx.amount)}</span>
               </div>
             ))}
           </div>
        </div>

      </div>
      <GlobalNav />
    </div>
  );
}
